package Construction;

import java.awt.Graphics;

import org.w3c.dom.Node;

public abstract class Constructeur 
{
	abstract boolean resoudre (Node s, Graphics g);
}
