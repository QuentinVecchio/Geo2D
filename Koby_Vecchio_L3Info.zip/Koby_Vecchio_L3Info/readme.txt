Pour effectuer un dessin, lancer ServeurGeo2DKV,
Puis ouvrez le projet Qt dans Client_Simple et compiler-le.

Vous pouvez � tout moment modifier le main.cpp dans le dossier Sources.

Koby Dylan & Vecchio Quentin