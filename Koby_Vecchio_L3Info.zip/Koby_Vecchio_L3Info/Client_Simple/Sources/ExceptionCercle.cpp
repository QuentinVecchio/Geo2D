#include "../Headers/ExceptionCercle.h"


ExceptionCercle::ExceptionCercle() :ExceptionGeo2D("Erreur, rayon négatif saisi."){}

ExceptionCercle::~ExceptionCercle()
{
}
