#include "constructeur.h"

Constructeur::Constructeur()
{
}
