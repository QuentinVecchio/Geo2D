#ifndef EXCEPTIONCERCLE_H
#define EXCEPTIONCERCLE_H
#include "../Headers/ExceptionGeo2D.h"

class ExceptionCercle : public ExceptionGeo2D{
public:
    ExceptionCercle();
    ~ExceptionCercle();
};

#endif // EXCEPTIONCERCLE_H
